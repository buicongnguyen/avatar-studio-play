# Avatar Studio → Godot

Tested with Godot 4.7.2 stable. Export from **Shots → Game model → Export game GLB**. Keep the two `.gd` files together. They are small, local import utilities; no service or plugin installation is needed.

## Editor import

1. Put the GLB and this helper folder inside your Godot project.
2. Select the GLB in the FileSystem dock. In the Import dock, set **Import Script** to `avatar_post_import.gd`, then **Reimport**.
3. Instantiate the imported scene. Its AnimationPlayer contains the exported clips. The helper preserves the morph defaults declared in your GLB, including negative body controls.
4. For a precise comparison with the studio, open Advanced Import Settings, select **AnimationPlayer**, and disable **Optimizer → Enabled** before reimporting. Leave it enabled for a smaller game asset if the resulting motion looks correct for your game; test floor contacts first.

For audit renders we also disabled mesh compression. That is an audit setting, not a universal requirement for mobile games. Mesh compression alone did not fix the small animation difference in the tested male avatar.

## Runtime GLB loading

```gdscript
const AvatarDefaults = preload("res://avatar_import/avatar_gltf_defaults.gd")

func load_avatar(path: String) -> Node:
    var document := GLTFDocument.new()
    var state := GLTFState.new()
    var error := document.append_from_file(path, state)
    if error != OK:
        push_error("Cannot load avatar: " + str(error))
        return null
    var scene := document.generate_scene(state, 30, false, false)
    if scene == null:
        return null
    var restored := AvatarDefaults.restore(scene, state.json)
    if not restored.available:
        push_error(str(restored.errors))
        scene.free()
        return null
    return scene
```

Use the helper before playing animation. Runtime loading already provides `state.json`; it does not need to reopen the GLB. Editor post-import instead reads the source GLB or glTF. If you deliberately rename imported mesh nodes, alter morph order or use another import pipeline, the helper may reject the scene rather than apply weights to the wrong mesh. This helper is for the studio's named exports, not an arbitrary skeleton conversion tool.

The tested imports do not create a RESET animation. If you add your own RESET animation or morph animation tracks later, set their defaults intentionally; playback can override the instance values restored during import.

## What the test proves

Three real portable exports were checked: a customized Korean gymnast, lean Asian man, and ponytail avatar. Without restoration, the tested Godot imports lost negative initial body weights. Maximum sampled differences were 5.07 mm and 10.85 mm on the first two avatars. With restoration, runtime import differences were below 0.09 mm; editor import with the animation optimizer disabled was below 0.08 mm. All 189 exported clips were present; 1,323 sampled poses had finite, nonsingular bone transforms. These sampled checks are not an all-frames collision or visual-quality guarantee.

Lighting and material appearance depend on your Godot environment. The three native render checks still show existing garment intersections in some poses. Runtime touch, physics, foot/hand support IK and paired choreography are app behavior, not glTF animations. Recreate those systems in your game. Authored clip corrections and fitted garment geometry export normally.

Sources: [Godot glTF runtime loading](https://docs.godotengine.org/en/stable/classes/class_gltfdocument.html), [post-import scripts](https://docs.godotengine.org/en/stable/classes/class_editorscenepostimport.html), [advanced animation import](https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/advanced_import_settings.html).
