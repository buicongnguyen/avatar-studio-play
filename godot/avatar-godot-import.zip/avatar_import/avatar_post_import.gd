@tool
extends EditorScenePostImport
## Select this script under the GLB's Import > Import Script, then Reimport.
const Defaults = preload("avatar_gltf_defaults.gd")

func _post_import(scene: Node) -> Object:
	var data = Defaults.read_json(get_source_file())
	if data.is_empty():
		push_error("Avatar import: cannot read glTF morph defaults.")
		return null
	var result = Defaults.restore(scene, data)
	if not result.available:
		push_error("Avatar import: " + str(result.errors))
		return null
	scene.set_meta("avatar_morph_defaults", result)
	return scene
