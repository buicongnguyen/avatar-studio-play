extends RefCounted
## Restore declared glTF morph defaults after Godot runtime scene generation.
## This reads the asset itself; it never bakes a pose or changes rig/morph data.
static func restore(scene: Node, document_json: Variant) -> Dictionary:
	var result = {"available": false, "meshes": 0, "weights": 0, "negative_weights": 0, "errors": []}
	if not is_instance_valid(scene) or scene.is_queued_for_deletion():
		result.errors.append("Missing or disposed scene")
		return result
	if not document_json is Dictionary:
		result.errors.append("glTF document must be a dictionary")
		return result
	var nodes = document_json.get("nodes", [])
	var definitions = document_json.get("meshes", [])
	if not nodes is Array or not definitions is Array:
		result.errors.append("glTF nodes and meshes must be arrays")
		return result
	var instances = {}
	var queue = [scene]
	var plan = []
	var planned_instances = {}
	var source_names = {}
	while not queue.is_empty():
		var current = queue.pop_back()
		queue.append_array(current.get_children())
		if current is MeshInstance3D:
			var key = str(current.name)
			if not instances.has(key): instances[key] = []
			instances[key].append(current)
	for node in nodes:
		if not node is Dictionary:
			result.errors.append("glTF node must be a dictionary")
			continue
		if not node.has("mesh"):
			continue
		var mesh_index = node.mesh
		if (typeof(mesh_index) != TYPE_INT and typeof(mesh_index) != TYPE_FLOAT) or not is_finite(float(mesh_index)):
			result.errors.append("Mesh reference must be a finite integer")
			continue
		if mesh_index < 0 or mesh_index >= definitions.size() or float(mesh_index) != floor(float(mesh_index)):
			result.errors.append("Invalid mesh reference")
			continue
		var definition = definitions[int(mesh_index)]
		if not definition is Dictionary:
			result.errors.append("glTF mesh must be a dictionary")
			continue
		var values = node.get("weights", definition.get("weights", []))
		if not values is Array:
			result.errors.append("Morph weights must be an array")
			continue
		if values.is_empty():
			continue
		var source_name = node.get("name", "")
		if not source_name is String or source_name.is_empty():
			result.errors.append("Weighted glTF node needs a nonempty name")
			continue
		if source_names.has(source_name):
			result.errors.append("Duplicate weighted glTF node name: " + source_name)
			continue
		source_names[source_name] = true
		var matches = instances.get(source_name, [])
		if matches.size() != 1:
			result.errors.append("Missing or ambiguous mesh node: " + source_name)
			continue
		var instance: MeshInstance3D = matches[0]
		if planned_instances.has(instance.get_instance_id()):
			result.errors.append("Mesh instance is targeted more than once: " + source_name)
			continue
		planned_instances[instance.get_instance_id()] = true
		if instance.mesh == null:
			result.errors.append("Missing mesh resource: " + source_name)
			continue
		if instance.get_blend_shape_count() != values.size():
			result.errors.append("Morph count mismatch: " + str(instance.name))
			continue
		var extras = definition.get("extras", {})
		if not extras is Dictionary or not extras.get("targetNames", []) is Array:
			result.errors.append("Morph extras/targetNames must be a dictionary/array")
			continue
		var names = extras.get("targetNames", [])
		if not names.is_empty() and names.size() != values.size():
			result.errors.append("Morph name count differs: " + source_name)
			continue
		for i in values.size():
			if (typeof(values[i]) != TYPE_INT and typeof(values[i]) != TYPE_FLOAT) or not is_finite(float(values[i])):
				result.errors.append("Nonfinite morph value")
				continue
			if not names.is_empty() and (not names[i] is String or str(instance.mesh.get_blend_shape_name(i)) != names[i]):
				result.errors.append("Morph names differ: " + str(instance.name))
				continue
		plan.append({"instance": instance, "values": values})
	if not result.errors.is_empty():
		return result
	for entry in plan:
		for i in entry.values.size():
			entry.instance.set_blend_shape_value(i, entry.values[i])
			result.weights += 1
			if entry.values[i] < 0:
				result.negative_weights += 1
		result.meshes += 1
	result.available = true
	return result

static func read_json(path: String) -> Dictionary:
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null: return {}
	if path.to_lower().ends_with(".gltf"):
		var parsed = JSON.parse_string(file.get_as_text())
		return parsed if parsed is Dictionary else {}
	if file.get_length() < 20 or file.get_32() != 0x46546C67 or file.get_32() != 2:
		return {}
	var length = file.get_32()
	var json_size = file.get_32()
	if length != file.get_length() or file.get_32() != 0x4E4F534A or json_size > length - 20:
		return {}
	var parsed = JSON.parse_string(file.get_buffer(json_size).get_string_from_utf8())
	return parsed if parsed is Dictionary else {}
